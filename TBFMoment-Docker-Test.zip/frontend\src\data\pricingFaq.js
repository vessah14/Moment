// Questions fréquentes de la page Tarifs : affichées sur la page et publiées dans les
// données structurées (FAQPage). Elles doivent décrire le fonctionnement réel des offres.
export const PRICING_FAQ = [
  {
    q: 'Je fais un seul mariage. Dois-je payer tous les mois ?',
    a: "Non. Les offres sont sans engagement et ne se renouvellent pas toutes seules : vous payez un mois, vous préparez et vivez votre événement, puis votre compte repasse à l'offre Free.",
  },
  {
    q: 'Comment je paie ?',
    a: "Par Orange Money ou MTN Mobile Money, sur la page de paiement sécurisée de Notch Pay. Votre offre s'active dès que le paiement est confirmé.",
  },
  {
    q: "Et si j'ai plus d'invités que prévu ?",
    a: "Vous pouvez passer à l'offre supérieure à tout moment depuis vos paramètres. La nouvelle offre démarre aussitôt, pour un mois.",
  },
  {
    q: 'Mes invités doivent-ils créer un compte ?',
    a: 'Non. Ils ouvrent le lien reçu sur WhatsApp, répondent en quelques secondes et reçoivent leur pass. Aucune application à installer, et ils ne paient jamais rien pour répondre.',
  },
  {
    q: "Pourquoi le logo est-il dans l'offre Business ?",
    a: "Une école, une entreprise ou une association qui publie sous son nom a besoin d'une page à son image, sans notre mention. Business est pensé pour ces structures, avec une facture à leur nom.",
  },
]
